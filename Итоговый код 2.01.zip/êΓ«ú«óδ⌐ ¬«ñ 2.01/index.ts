function sum(a: number, b: number) {
    return a + b
}

const n1: number = 40
const n2: number = 2.56

let a = 12
let b = Infinity
let c = NaN
let d: 42 = 24 // error
let e = 0x1
let f = 0.1

console.log(sum(n1, n2))